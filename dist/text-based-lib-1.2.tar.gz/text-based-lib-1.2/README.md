# Text-Based Lib

TBLIB is a python library made for creating text-based games in the terminal

All the documentation is located here : https://tblib-docs.devplodocus.repl.co